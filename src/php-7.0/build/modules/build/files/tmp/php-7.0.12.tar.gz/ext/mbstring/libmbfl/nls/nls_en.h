#ifndef MBFL_NLS_EN_H
#define MBFL_NLS_EN_H

#include "mbfilter.h"

extern const mbfl_language mbfl_language_english;

#endif /* MBFL_NLS_EN_H */
